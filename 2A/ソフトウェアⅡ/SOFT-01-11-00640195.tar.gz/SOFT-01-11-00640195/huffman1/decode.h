#ifndef HUFFMAN_DECODE_H
#define HUFFMAN_DECODE_H

void decode(const char *input_file, const char *output_file);

#endif
