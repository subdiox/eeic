#ifndef HUFFMAN_ENCODE_H
#define HUFFMAN_ENCODE_H

void encode(const char *input_file, const char *output_file);

#endif
